import React, { useState, useEffect } from 'react';
// import RegistrationForm from './RegistrationForm';
// import UserProfile from './UserProfile';
import GettingStarted from './GettingStarted'
import './styles.css'
import Navbar from './Navbar';

const App = () => {

  return (
    <div>
      <Navbar/>
       <GettingStarted/>
    </div>
)
  // const [userData, setUserData] = useState(null);

  // useEffect(() => {
  //   // Fetch user data from API
  //   const user = {
  //     username: 'John Doe',
  //     email: 'john.doe@example.com',
  //     stylePreferences: {
  //       fashion: 'classic',
  //       music: 'rock',
  //       art: 'modern',
  //     },
  //   };
  //   setUserData(user);
  // }, []);

  // return (
  //   <div>
  //     {userData ? (
  //       <UserProfile {...userData} />
  //     ) : (
  //       <RegistrationForm
  //         onSubmit={(username, email, password, stylePreferences) => {
  //           // Call API to register user and store preferences
  //           const user = {
  //             username,
  //             email,
  //             stylePreferences,
  //           };
  //           setUserData(user);
  //         }}
  //       />
  //     )}
  //   </div>
  // );
};

export default App;
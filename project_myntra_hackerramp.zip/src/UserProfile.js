import React from 'react';

const UserProfile = ({ username, email, stylePreferences }) => {
  return (
    <div>
      <h1>User Profile</h1>
      <p>Username: {username}</p>
      <p>Email: {email}</p>
      <h2>Style Preferences</h2>
      <ul>
        <li>Fashion: {stylePreferences.fashion}</li>
        <li>Music: {stylePreferences.music}</li>
        <li>Art: {stylePreferences.art}</li>
      </ul>
    </div>
  );
};

export default UserProfile;
import React, { useState } from 'react';
import { Button, Form, FormGroup, Label, Input } from 'reactstrap';

const RegistrationForm = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [stylePreferences, setStylePreferences] = useState({
    fashion: '',
    music: '',
    art: '',
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    // Call API to register user and store preferences
    console.log('Registered user:', username, email, password, stylePreferences);
  };

  return (
    <Form onSubmit={handleSubmit}>
      <FormGroup>
        <Label for="username">Username</Label>
        <Input
          type="text"
          id="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
        />
      </FormGroup>
      <FormGroup>
        <Label for="email">Email</Label>
        <Input
          type="email"
          id="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
        />
      </FormGroup>
      <FormGroup>
        <Label for="password">Password</Label>
        <Input
          type="password"
          id="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
        />
      </FormGroup>
      <FormGroup>
        <Label for="fashion">Fashion Style</Label>
        <Input
          type="select"
          id="fashion"
          value={stylePreferences.fashion}
          onChange={(event) =>
            setStylePreferences({...stylePreferences, fashion: event.target.value })
          }
        >
          <option value="">Select</option>
          <option value="classic">Classic</option>
          <option value="trendy">Trendy</option>
          <option value="bohemian">Bohemian</option>
        </Input>
      </FormGroup>
      <FormGroup>
        <Label for="music">Music Style</Label>
        <Input
          type="select"
          id="music"
          value={stylePreferences.music}
          onChange={(event) =>
            setStylePreferences({...stylePreferences, music: event.target.value })
          }
        >
          <option value="">Select</option>
          <option value="rock">Rock</option>
          <option value="pop">Pop</option>
          <option value="hiphop">Hip-Hop</option>
        </Input>
      </FormGroup>
      <FormGroup>
        <Label for="art">Art Style</Label>
        <Input
          type="select"
          id="art"
          value={stylePreferences.art}
          onChange={(event) =>
            setStylePreferences({...stylePreferences, art: event.target.value })
          }
        >
          <option value="">Select</option>
          <option value="modern">Modern</option>
          <option value="contemporary">Contemporary</option>
          <option value="abstract">Abstract</option>
        </Input>
      </FormGroup>
      <Button type="submit">Register</Button>
    </Form>
  );
};

export default RegistrationForm;
import React from 'react';
import './styles.css';

function GettingStarted() {
  return (
    <div className="container">
      <div className="sub-con">
        <section className="right">
        <div className="header">
          <h1>Engaging Fashion Experiences for Gen Z</h1>
          {/* <div className="links">
            <a href="#" className="link">Add a link</a>
            <a href="#" className="link">15</a>
          </div> */}
        </div>
        
        <div className="content">
          <p>Discover personalized fashion tips, exclusive virtual meetups, and interactive style challenges to keep Gen Z audiences coming back to the platform.</p>
          <div className="buttons">
            <button className="get-started">Get Started</button>
            <button className="learn-more">Learn More</button>
          </div>
        </div>
        </section>
        
        <section className="left">
        <div className="homeImage">
          <img src="https://imgproxy.gamma.app/resize/quality:80/resizing_type:fit/width:1200/https://cdn.gamma.app/tkbn4jrymi6qwf4/de3b4c5196084394854c0ed2f16e50b4/original/global-girls-fb.jpg" alt="Getting Started" />
        </div>
        </section>
      </div>
{/* 
      <div className="sidebar">
        <ul>
          <li>Personalized Fashion Tips</li>
          <li>Interactive Fashion Challenges</li>
          <li>Wear Jeragation</li>
          <li>Fostering Community Engagement</li>
          <li>Powering the Fashion Experience</li>
          <li>Benefits of the Solution</li>
        </ul>
      </div> */}

       
      {/* <div className="footer">
        <p>35°C Haze מזון. בי.</p>
      </div> */}
    </div>
  );
}

export default GettingStarted;